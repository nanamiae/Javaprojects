package dominest.app;

import java.awt.Image;
import java.awt.Point;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JOptionPane;

import dominest.elemento.*;
import dominest.elemento.domino.*;
import prof.jogos2D.image.ComponenteAnimado;
import prof.jogos2D.image.ComponenteMultiAnimado;
import prof.jogos2D.image.ComponenteMultiVisual;
import prof.jogos2D.image.ComponenteMultiplo;
import prof.jogos2D.image.ComponenteSimples;
import prof.jogos2D.image.ComponenteVisual;

/**
 * Esta classe tem como tarefa ler o ficheiro de nível,
 * bem como carregar as imagens das várias animações
 */
public class NivelReader {

	// animações e imagens a serem usadas no jogo
	private static ComponenteMultiVisual imagensPlataforma; 
	private static ComponenteVisual imagensEscadas[] = new ComponenteVisual[3];
	private static ComponenteMultiVisual animsFormiga;
	private static ComponenteMultiVisual animsDomino;
	private static ComponenteMultiVisual animsFinal;
	private static ComponenteMultiVisual animsAtraso;
	private static ComponenteMultiVisual animsBomba;
	private static ComponenteMultiVisual animsContinuo;
	private static ComponenteMultiVisual animsDivisivel;
	private static ComponenteMultiVisual animsDesaparece;
	private static ComponenteMultiVisual animsElevador;
	private static ComponenteMultiVisual animsLigador;
	private static ComponenteMultiVisual animsParede;
	
	
	/** método para ler o ficheiro de nível
	 * @param level número do nivel
	 * @return o Nivel criado
	 */
	public static Nivel lerNivel( int level ){
		String file = "niveis\\nivel" + level + ".txt";

		try (BufferedReader fnivel = new BufferedReader( new FileReader( file ) );){
			setupImagensFormiga();
			setupImagensDomino();
			
			// ler o tempo que tem para acabar o nivel
			int tempoLimite = Integer.parseInt( proximaLinha( fnivel ) );

			// ler o fundo
			String fundoFich = proximaLinha( fnivel );
			ComponenteVisual fundo = new ComponenteSimples( new Point(0,0), fundoFich );
			Nivel novoNivel = new Nivel( tempoLimite, fundo );

			// ignorar tudo até às plataformas e depois ler as plataformas
			while( !proximaLinha(fnivel).equals("#PLATAFORMAS") );
			String linha;
			int platComp = lerPlataformas(fnivel, novoNivel);

			// ignorar tudo até às escadas ou à formiga
			linha = proximaLinha( fnivel );
			while( !linha.equals("#ESCADAS") && !linha.equals("#FORMIGA") )
				linha = proximaLinha( fnivel );
			
			if( linha.equals("#ESCADAS") )
				lerEscadas(fnivel, novoNivel, platComp);
			
			// agora vai ler a informação da formiga
			// ler o índice da plataforma inicial
			String infoFormiga = fnivel.readLine();
			int platIdx = Integer.parseInt( infoFormiga );
			novoNivel.setFormiga( new Formiga( novoNivel.getPlataformas().get(platIdx), setupImagensFormiga() ) );

			// ler a info da porta de saída
			// ler a imagem da porta
			ComponenteAnimado cp = (ComponenteAnimado)lerComponenteVisual( proximaLinha( fnivel ).split("\t"), 0);
			// ler a área da porta (x, y, comprimento, altura)
			String infoP[] = proximaLinha( fnivel ).split("\t");
			Point pos = lerPosicao( infoP[0], infoP[1] );
			int comp = Integer.parseInt( infoP[2] );
			int alt = Integer.parseInt( infoP[3] );
			Porta porta = new Porta(pos, comp, alt, cp );
			novoNivel.setPorta( porta );
			
			return novoNivel;
		}
		catch( Exception e ){
			// se falhou a ler o n�vel sai do jogo 
			JOptionPane.showMessageDialog( null, "Erro - " + e.getMessage() + " - na leitura do nivel " + file );
			e.printStackTrace();
			return null;
		}		
	}

	/** faz a leitura de todas as plataformas
	 * @param fnivel ficheiro com a informação
	 * @param novoNivel nível ao qual adicionar as plataformas
	 * @return o comprimento de cada plataforma
	 * @throws IOException caso alguma coisa corra mal
	 */
	private static int lerPlataformas(BufferedReader fnivel, Nivel novoNivel) throws IOException {
		String infoPlat[] = proximaLinha( fnivel ).split("\t");
		int platComp = Integer.parseInt( infoPlat[0] );
		int platOffset = Integer.parseInt( infoPlat[1] ); 
		
		// ler as imagens das plataformas
		imagensPlataforma = new ComponenteMultiVisual();
		imagensPlataforma.addComponenteVisual("isolada", lerComponenteVisual( proximaLinha( fnivel ).split("\t"), 0));
		imagensPlataforma.addComponenteVisual("inicial", lerComponenteVisual( proximaLinha( fnivel ).split("\t"), 0));
		imagensPlataforma.addComponenteVisual("meio", lerComponenteVisual( proximaLinha( fnivel ).split("\t"), 0));
		imagensPlataforma.addComponenteVisual("final", lerComponenteVisual( proximaLinha( fnivel ).split("\t"), 0));
		
		// ler a informação das plataformas
		// cada informação deverá estar separada por \t (TAB)
		String linha = proximaLinha( fnivel );
		while( !linha.equals("#FIMPLAT") ){
			criarPlataforma( novoNivel, platComp, platOffset, linha );
			linha = proximaLinha( fnivel );
		}
		return platComp;
	}
	
	/** faz a leitura de todas as escadas
	 * @param fnivel ficheiro com a informação
	 * @param novoNivel nivel ao qual adicionar as escadas
	 * @param platComp comprimento das plataformas (ajuda a posicionar as escadas) 
	 * @throws IOException caso alguma coisa corra mal
	 */
	private static void lerEscadas(BufferedReader fnivel, Nivel novoNivel, int platComp) throws IOException {
		String linha;
		// ler a altura e o offset
		String info[] = proximaLinha( fnivel ).split("\t");
		int alturaEsc = Integer.parseInt( info[0] );
		int offsetEsc = Integer.parseInt( info[1] );
		
		// ler as imagens das escadas
		imagensEscadas[0] = lerComponenteVisual( proximaLinha( fnivel ).split("\t"), 0);
		imagensEscadas[1] = lerComponenteVisual( proximaLinha( fnivel ).split("\t"), 0);
		imagensEscadas[2] = lerComponenteVisual( proximaLinha( fnivel ).split("\t"), 0);
		
		// ler todas as escadas
		linha = proximaLinha( fnivel );
		while( !linha.equals("#FIMESC") ){
			criarEscadas( novoNivel, alturaEsc, offsetEsc, platComp, linha );
			linha = proximaLinha( fnivel );
		}
		
		while( !linha.equals("#FORMIGA") )
			linha = proximaLinha( fnivel );
	}
	
	/** faz a leitura da próxima linha que tenha informação
	 * @param fin feicheiro de onde ler
	 * @return A linha lida
	 * @throws IOException caso algo corra mal
	 */
	private static String proximaLinha( BufferedReader fin ) throws IOException {
		String linha = fin.readLine();
		while( linha != null && linha.startsWith("*") )
			linha = fin.readLine();
		return linha;
	}

	/** faz a leituras as animações da formiga
	 * @return as animações da formiga
	 * @throws IOException caso algo corra mal na leitura
	 */
	private static ComponenteMultiVisual setupImagensFormiga() throws IOException {
		// se já carregou as imagens, não precisa de voltar a ler
		if( animsFormiga != null ) 
			return animsFormiga;
		
		animsFormiga = new ComponenteMultiVisual();
		animsFormiga.addComponenteVisual( "pegar", readImages( "anims/formiga2/pegar", 2 )  );
		animsFormiga.addComponenteVisual( "pegarE", readImages( "anims/formiga2/pegar_esq", 2 )  );
		animsFormiga.addComponenteVisual( "largar", readImages( "anims/formiga2/largar", 2 )  );
		animsFormiga.addComponenteVisual( "parada", readImages( "anims/formiga2/parada", 2 )  );
		animsFormiga.addComponenteVisual( "paradaC", readImages( "anims/formiga2/parada_carregada", 2 )  );
		animsFormiga.addComponenteVisual( "andar", readImages( "anims/formiga2/andar", 2 )  );
		animsFormiga.addComponenteVisual( "andarE", readImages( "anims/formiga2/andar_esq", 2 )  );
		animsFormiga.addComponenteVisual( "carregar", readImages( "anims/formiga2/andar_carregada", 2 )  );
		animsFormiga.addComponenteVisual( "carregarE", readImages( "anims/formiga2/andar_carregada_esq", 2 )  );
		animsFormiga.addComponenteVisual( "subir", readImages( "anims/formiga2/subir", 2 )  );
		ComponenteVisual descer = animsFormiga.getComponenteVisual("subir").clone();
		descer.inverter();
		animsFormiga.addComponenteVisual( "descer", descer );
		animsFormiga.addComponenteVisual( "subirC", readImages( "anims/formiga2/subir_carregada", 2 )  );
		ComponenteVisual descerC = animsFormiga.getComponenteVisual("subirC").clone();
		descerC.inverter();
		animsFormiga.addComponenteVisual( "descerC", descerC );
		animsFormiga.addComponenteVisual( "cair", readImages( "anims/formiga2/cair", 2 )  );
		animsFormiga.addComponenteVisual( "debrucar", readImages( "anims/formiga2/debrucar", 2 )  );
		animsFormiga.addComponenteVisual( "empurrarD", readImages( "anims/formiga2/empurrar_dir", 2 )  );
		animsFormiga.addComponenteVisual( "empurrarE", readImages( "anims/formiga2/empurrar_esq", 2 )  );
		return animsFormiga;
	}

	/** faz a leitura das várias imagens que estão num dado diretório
	 * @param dir diretório onde ler as imagens
	 * @param delay delçay a usar nas animações
	 * @return a animação lida
	 * @throws IOException caso algo corra mal na leitura
	 */
	private static ComponenteVisual readImages( String dir, int delay ) throws IOException {
		File animDir = new File( dir );
		File files[] = animDir.listFiles();
		Image []imagens = new Image[ files.length ];
		for( int i=0; i < files.length; i++ ) {
			imagens[i] = ImageIO.read( files[i] );
		}
		return new ComponenteAnimado( new Point(), imagens, delay);
	}
	
	/** faz a leitura das animações do dominó
	 * @throws IOException caso algo corra mal
	 */
	private static void setupImagensDomino() throws IOException {
		// se já as leu antes, não é preciso voltar a ler
		if( animsDomino != null )
			return;
		
		animsDomino = setupImagensDomino( "domino" );
		animsFinal = setupImagensDomino( "final" );
		animsAtraso = setupImagensDomino( "atraso" );
		animsBomba = setupImagensDomino( "bomba" );
		animsContinuo = setupImagensDomino( "continuo" );
		animsDivisivel = setupImagensDomino( "divisivel" );
		animsDesaparece = setupImagensDomino( "desaparece" );
		animsElevador = setupImagensDomino( "elevador" );
		animsLigador = setupImagensDomino( "ligador" );
		animsParede = setupImagensDomino( "parede" );
	}
	
	/** faz a leitura das animações de um dominó, indicando o seu diretório particular
	 * @param dominoDir nome do diretório com as imagens do dominó específico
	 * @return as animações existentes no diretório indicado
	 * @throws IOException caso algo corra mal na leitura
	 */
	private static ComponenteMultiVisual setupImagensDomino( String dominoDir ) throws IOException {
		// ler a nimação de pegar
		ComponenteMultiVisual anims = new ComponenteMultiVisual();
		ComponenteVisual pegar= readImages( "anims/"+ dominoDir + "/puxar", 2 );
		anims.addComponenteVisual( "pegar", pegar  );
		
		// ao inverter a animação de pegar, temos a animação de pousar
		ComponenteVisual repor = pegar.clone();
		repor.inverter();
		anims.addComponenteVisual( "repor", repor );
		
		// ler a animação de tombar 
		anims.addComponenteVisual( "tombar", readImages( "anims/"+ dominoDir + "/tombar", 2 )  );
		return anims;
	}

	/** le a info e cria uma plataforma
	 * @param novoNivel nivel ao qual adicionar a plataforma
	 * @param platComp comprimento da plataforma 
	 * @param platOffset offset entre a imagem e a posição
	 * @param linha linha contendo a informação da plataforma
	 * @throws IOException
	 */
	private static void criarPlataforma(Nivel novoNivel, int platComp, int platOffset, String linha) throws IOException {
		String info[] = linha.split("\t");
		// ler a posição da 1ª plataforma
		Point pos = lerPosicao( info[0], info[1] );
		String domino = info[2];
		// para todas as restantes plataformas
		for( int i=0; i < domino.length(); i++ ) {
			ComponenteMultiVisual img = imagensPlataforma.clone();
			Plataforma plat = null;
			char dominoInfo = domino.charAt( i );
			if( dominoInfo == '.' )
				plat = new Plataforma( pos, platOffset, platComp, img, false ); 
			else {
				plat = new Plataforma( pos, platOffset, platComp, img, true );
				Domino d = null;
				switch( dominoInfo ) {
				case 'D': d = new Normal( animsDomino.clone() );  break; 
				case 'F': d = new Final(   animsFinal.clone() );  break; 
				case 'P': d = new Parede(  animsParede.clone() ); break;	
				case 'A': d = null ; // new Domino(  animsAtraso.clone() ); break; //NAO IMPLEMENTADO -- ATRASO
				case 'C': d = new Continuo(  animsContinuo.clone() ); break;
				case 'E': d = new Elevador( animsElevador.clone() ); break;
				case 'V': d = new Divisivel(  animsDivisivel.clone() ); break;
				case 'B': d = null ; //new Domino(  animsBomba.clone() ); break;//NAO IMPLEMENTADO -- BOMBA
				case 'L': d = new Ligador(  animsLigador.clone() ); break;
				case 'X': d = new Desaparece(  animsDesaparece.clone() ); break; 
				default: d = null;
				}
				if( d != null ) {
			        plat.setDomino( d );
			        novoNivel.addDomino( d );
				}
			}
			novoNivel.addPlataforma( plat );
			pos.x += platComp;
		}
	}

	/** faz a leitura e cria uma escada
	 * @param novoNivel nivel ao qual adicionar a escada
	 * @param alturaEsc a altura de cada escada
	 * @param offsetEsc offset entre a posição da escada e a sua imagem
	 * @param compPlat o comprimento da plataforma (ajuda a posicionar as escadas)
	 * @param linha linha com a informação da escada
	 */
	private static void criarEscadas(Nivel novoNivel, int alturaEsc, int offsetEsc, int compPlat, String linha) {
		String info[] = linha.split("\t");
		// ler a coordenada x, a y do fundo e a y do topo
		int x = Integer.parseInt( info[0] );
		int topo = Integer.parseInt( info[1] );
		int fundo = Integer.parseInt( info[2] );
		
		// ver quantos degraus intermédios são precisos
		int nMeios = (fundo - topo)/alturaEsc - 2;
		// cria a imagem da escada, usando as imagens do topo fundo e os meios necessários
		ComponenteMultiplo img = new ComponenteMultiplo();
		img.addComponente( new Point( x, topo+offsetEsc ), imagensEscadas[2].clone() );
		for( int i=1; i <= nMeios; i++ )
			img.addComponente( new Point( x, topo+i*alturaEsc+offsetEsc ), imagensEscadas[1].clone() );
		img.addComponente( new Point( x, fundo-alturaEsc+offsetEsc ), imagensEscadas[0].clone() );
		
		// adicionar a nova escada ao nível
		novoNivel.addEscada( new Escada( new Point(x, topo), new Point(x+compPlat, fundo), offsetEsc, img ) );
	}


	/** leitura de um componente visual
	 * @param info informação da linha
	 * @param idx índice a partir do qual está presente a info do componente
	 * @return o componente visual criado
	 * @throws IOException
	 */
	private static ComponenteVisual lerComponenteVisual(String[] info, int idx ) throws IOException {
		switch( info[idx] ) {
		case "CS":  return criarComponenteSimples( info, idx+1 );
		case "CA":  return criarComponenteAnimado( info, idx+1 );
		case "CMA": return criarComponenteMultiAnimado( info, idx+1 );
		}
		return null;
	}

	/** le a info e cria um componente simples
	 * Na linha a info é CS + nome da imagem
	 */
	private static ComponenteSimples criarComponenteSimples(String[] info, int idx) throws IOException {
		return new ComponenteSimples( info[idx] );
	}
	
	/** le a info e cria um componente animado
	 * Na linha a info é CA + nome da imagem + número de frames + delay na animação
	 */
	private static ComponenteAnimado criarComponenteAnimado(String[] info, int idx ) throws IOException {
		String nomeImg =  info[idx];
		int nFrames = Integer.parseInt( info[idx+1] );
		int delay = Integer.parseInt( info[idx+2] );
		return new ComponenteAnimado( new Point(0,0), nomeImg, nFrames, delay );
	}

	/** le a info e cria um componente multianimado
	 * Na linha a info é CMA + nome da imagem + número de animações + número de frames + delay
	 */
	private static ComponenteMultiAnimado criarComponenteMultiAnimado(String[] info, int idx ) throws IOException {
		String nomeImg =  info[idx];
		int nAnims =  Integer.parseInt( info[idx+1] );
		int nFrames = Integer.parseInt( info[idx+2] );
		int delay = Integer.parseInt( info[idx+3] );
		return new ComponenteMultiAnimado( new Point(0,0), nomeImg, nAnims, nFrames, delay );
	}

	/**lê uma posição em point
	 * @param strx coordenada x
	 * @param stry coordenada y
	 * @return a posição lida
	 */
	private static Point lerPosicao(String strx, String stry) {
		int x = Integer.parseInt(strx);
		int y = Integer.parseInt(stry);
		return new Point(x,y);
	}
}
