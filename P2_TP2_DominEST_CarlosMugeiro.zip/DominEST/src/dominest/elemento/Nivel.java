package dominest.elemento;

import java.awt.Graphics2D;
import java.awt.Point;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import dominest.elemento.domino.*;
import prof.jogos2D.image.ComponenteVisual;

/**
 * Classe que representa um nível do jogo.
 * O nível contém todos os elementos do jogo: formiga, dominós, escadas, etc
 * É responsável ainda por atualizar os vários elementos e garantir que estes
 * interagem uns com os outros
 */
public class Nivel {
	// elementos visuais presentes no jogo
	private ComponenteVisual fundo;
	private Formiga formiga;
	
	// variáveis para controlo do tempo
	private int tempoLimite; 
	private int tempoAtual;
	private long tempoInicio; 
	
	// saber se está a jogar e se ganhou
	private boolean estaJogar = false;
	private boolean ganhou;

	// os vários elementos do jogo
	private ArrayList<Domino> dominos = new ArrayList<Domino>();
	private ArrayList<Plataforma> plataformas = new ArrayList<Plataforma>();
	private ArrayList<Escada> escadas = new ArrayList<Escada>();
	private Porta porta;
	
	// mensagem com o motivo da derrota
	private String mensagem;

	/** Cria um nível
	 * @param tempoLimite tempo limite 
	 * @param fundo imagem de fundo 
	 */
	public Nivel(int tempoLimite, ComponenteVisual fundo) {
		this.tempoLimite = tempoLimite;
		this.fundo = fundo;
		tempoAtual = tempoLimite;
	}
	
	/** Começar a jogar o nível
	 */
	public void comecar() {
		estaJogar = true;
		tempoAtual = tempoLimite;		
		tempoInicio = System.currentTimeMillis();
		ganhou = false;
	}

	/** atualiza os elementos presentes
	 */
	public void atualizar() {
		if( !estaJogar )
			return;
		
		// mover a formiga
		formiga.atualizar();

		// ver os dominós, tendo o cuidado de começar de trás para a 
		// frente por causa de dominós removidos
		for( int i=dominos.size()-1; i >= 0 ; i-- )
			dominos.get(i).atualiza( );		
		
		// ver se já ganhou
		if( porta.estaCompletamenteAberta() && porta.estaDentro( formiga.getPosicaoPoint() ) ) {
			if( tempoAtual >= 0)
				ganhou = true;
			else 
				mensagem = "Não acabou dentro do tempo limite";			
			estaJogar = false;
		}
	}

	/** devolve a imagem de fundo
	 * @return  a imagem de fundo
	 */
	public ComponenteVisual getFundo() {
		return fundo;
	}

	/** altera a imagem de fundo
	 * @param fundo nova imagem de fundo
	 */
	public void setFundo(ComponenteVisual fundo) {
		this.fundo = fundo;
	}

	/** retorna a formiga
	 * @return a formiga
	 */
	public Formiga getFormiga() {
		return formiga;
	}

	/** define a formiga a jogar
	 * @param formiga nova formiga
	 */
	public void setFormiga(Formiga formiga) {
		this.formiga = formiga;
		formiga.setNivel( this );
	}

	/** retorna o tempo limite
	 * @return o tempo limite
	 */
	public int getTempoLimite() {
		return tempoLimite;
	}

	/** define o tempo limite
	 * @param tempoLimite novo tempo limite
	 */
	public void setTempoLimite(int tempoLimite) {
		this.tempoLimite = tempoLimite;
	}

	/** retorna o tempo atual do jogo
	 * @return o tempo atual do jogo
	 */
	public int getTempoAtual() {
		// atualizar o tempo actual
		if( estaJogar ) 
			tempoAtual = tempoLimite - ((int)(System.currentTimeMillis() - tempoInicio ) / 1000);
		return tempoAtual;
	}

	/** adiciona um dominó ao nível
	 * @param d o dominó a adicionar
	 */
	public void addDomino( Domino d ) {
		dominos.add( d );
		d.setNivel( this );
	}
	
	/** remove um dominó do jogo
	 * @param d dominó a remover
	 */
	public void removeDomino( Domino d ) {
		dominos.remove( d );
		
	}
	
	/** desenha todos os elementos 
	 * @param g ambiente gráfico onde desenhar
	 */
	public void desenhar(Graphics2D g) {
		fundo.desenhar( g );
		
		porta.desenhar( g );
		
		for( Plataforma p : plataformas )
			p.desenhar( g );
		
		// desenhar os dominós, menos o que está a ser carregado
		for( Domino o : dominos )
			if( o != formiga.getCarregado() )
				o.desenhar( g );
		
		formiga.desenhar( g );
		// se estiver a carregar também o desenha
		if( formiga.getCarregado() != null )
			formiga.getCarregado().desenhar( g );
		
		for( Escada e : escadas )
			e.desenhar( g );
	}

	/** indica se o nível está a ser jogado 
	 * @return true, se está a ser jogado
	 */
	public boolean estaJogar() {
		return estaJogar;
	}
	
	/** indica se o nível foi completado com sucesso
	 * @return true se nivel foi ganho, false se ainda está a jogar ou se perdeu
	 */
	public boolean ganhou() {
		return ganhou;
	}

	/** indica ao nível que este foi perdido
	 * @param msg motivo porque perdeu
	 */
	public void perdeNivel(String msg) {
		estaJogar = false;
		ganhou = false;
		mensagem = msg;
	}
	
	/** devolve a mensagem de derrota
	 * @return a mensagem de derrota
	 */
	public String getMensagem() {
		return mensagem;
	}
	
	/** retorna uma lista com os dominós
	 * @return  uma lista com os dominós
	 */
	public List<Domino> getObstaculos() {		
		return Collections.unmodifiableList( dominos );
	}

	/** adiciona uma plataforma ao jogo
	 * @param plat plataforma a adicionar
	 */
	public void addPlataforma(Plataforma plat) {		
		int x = plat.getPosicao().x;
		int y = plat.getPosicao().y;
		
		// ver se é para ligar a alguma que já exista		
		for( Plataforma p : plataformas ) {
			// estão na mesma fila, será que estão pegadas?
			if( p.getPosicao().y == y ) {
				// está antes?
				if( x-p.getComprimento() == p.getPosicao().x ) {
					p.setProxima( plat );
					plat.setAnterior( p );
				}
				// está depois?
				else if( x+p.getComprimento() == p.getPosicao().x ) {
					p.setAnterior( plat );
					plat.setProxima( p );
				}
			}
		}
		plataformas.add( plat );
	}
	
	/** retorna a platafora que esteja numa dada coordenada
	 * @param pt coordenada a testar se tem plataforma
	 * @return a plataforma, ou null caso não haja
	 */
	public Plataforma getPlataformaAt( Point pt ) {
		for( Plataforma p : plataformas ) {
			if( p.estaDentro(pt) ) 
				return p;			
		}
		return null;
	}

	/** remove uma plataforma do jogo
	 * @param p plataforma a remover
	 */
	public void removePlataforma(Plataforma p) {
		if( p == null )
			return;
		plataformas.remove( p );
		// atualizar as anteriores e seguintes das plataformas pegadas
		if( p.getAnterior() != null )
			p.getAnterior().setProxima( null );
		if( p.getProxima() != null )
			p.getProxima().setAnterior( null );
	}

	/** procura uma plataforma abaixo de uma dada coordenada
	 * @param p coordenada abaixo da qual se pretende a plataforma
	 * @return a plataforma mais perto da coordenada indicada, ou null caso não haja
	 */
	public Plataforma getPlataformaAbaixo( Point p ) {
		Plataforma alvo = null;
		for( Plataforma plat : plataformas ) {
			int x = plat.getPosicao().x;
			int y = plat.getPosicao().y;
			if( p.x >= x && p.x < x + plat.getComprimento() && p.y < y ) {
				if( alvo == null || alvo.getPosicao().y > y )
					alvo = plat;
			}
		}
		return alvo;
	}
	
	/** procura uma plataforma acima de uma dada coordenada
	 * @param p coordenada acima da qual se pretende a plataforma
	 * @return a plataforma mais perto da coordenada indicada, ou null caso não haja
	 */
	public Plataforma getPlataformaAcima( Point p ) {
		Plataforma alvo = null;
		for( Plataforma plat : plataformas ) {
			int x = plat.getPosicao().x;
			int y = plat.getPosicao().y;
			if( p.x >= x && p.x <= x + plat.getComprimento() && p.y > y ) {
				if( alvo == null || alvo.getPosicao().y < y )
					alvo = plat;
			}
		}
		return alvo;
	}

	/** retorna todas as plataformas 
	 * @return todas as plataformas
	 */
	public List<Plataforma> getPlataformas() {
		return Collections.unmodifiableList( plataformas );
	}

	/** adiciona uma escada
	 * @param escada esacada a adicionar
	 */
	public void addEscada(Escada escada) {
		escadas.add( escada );		
	}

	/** indica qual a escada que está numa dada coordenada
	 * @param pos coordenada onde verificar se existe escada
	 * @return a escada encontrada, ou null caso não haja
	 */
	public Escada getEscadaAt(Point pos ) {
		for( Escada e : escadas ) {
			if( e.estaDentro( pos ) )
				return e;
		}
		return null;
	}

	/** devolve uma lista com todos os dominós
	 * @return uma lista com todos os dominós
	 */
	public List<Domino> getDominos() {
		return Collections.unmodifiableList( dominos );
	}

	/** define a porta de saída do nível
	 * @param porta a porta de saída
	 */
	public void setPorta(Porta porta) {
		this.porta = porta;		
	}
	
	/** devolve a porta de saída
	 * @return a porta de saída
	 */
	public Porta getPorta() {
		return porta;
	}
}
