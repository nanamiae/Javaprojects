package dominest.elemento;

/** Nesta interface declaram-se algumas constantes que definem
 * valores a usar no jogo, como distãncias entre elementos,
 * ângulos a usar para saber se os dominós batem nos outros, etc
 * 
 * Numa versão futura (mas não neste trabalho), estes valores
 * poderiam ser colocados num ficheiro e assim serem diferentes
 * de nível para nível ou se se atualizarem as imagens. 
 */
public interface ConstantesJogo {
	/** offset entre a posição da plataforma e o centro do dominó em y */
	int OFFSET_DOMINO_PLATAFORMA_Y = 40;
	
	/** offset entre a posição da plataforma e o centro do dominó em x*/
	int OFFSET_DOMINO_PLATAFORMA_X = 20;
	
	/** offset entre a posição na plataforma e a parte de baixo desta (dominós que sobem) */
	int OFFSET_DOMINO_FUNDOPLATAFORMA = 95;
	
	/** altura máxima entre plataformas de modo a que um dominó que sobe bata no de baixo */
	int ALTURA_MAX_ELEVADORBATER = 120;
	
	/** coordenada que indica o fundo do jogo (onde desaparecem dominós e a formiga morre) */
	int FUNDO_JOGO = 750;
	
	/** distância entre o chão da plataforma e o centro da imagem da formiga	 */
	int OFFSET_FORMIGA_PLAT = -35; 

	/** distância entre o donimó e a formiga quando está a ser pousado/reposto */
	int OFFSET_DOMINO_CARREGADO = 15;
	
	/** distância a mover o dominó para a esquerda quando está carregado */
	int OFFSET_DOMINO_CARREGADO_ESQ = 36;
	
	/** distãncia entre a formiga e o dominó quando está nas escadas */
	int OFFSET_DOMINO_ESCADAS = 30;
	
	/** número da frame de animação de empurrar em que a formiga está na posição de empurrar */
	int FRAME_FORMIGA_EMPURRA = 8;
	
	/** distãncia que a formiga tem de mover para empurrar para o lado esquerdo */
	int OFFSET_EMPURRAR_ESQ = 40;
	
	/** altura máxima que a formiga pode cair sem morrer */
	int ALTURA_MAXIMA_QUEDA = 200;
	
	/** velocidade da formiga */
	double VELOC_MOV_FORMIGA = 5; 
	
	/** velocidade de queda do dominó */
	double VELOC_QUEDA_DOMINO = 8;
	
	/** tempo que demora um domino Atraso até cair */
	int DOMINO_ATRASO = 1500;
}
