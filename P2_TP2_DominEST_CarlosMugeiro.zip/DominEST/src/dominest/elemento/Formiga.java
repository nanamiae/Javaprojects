package dominest.elemento;

import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.geom.Point2D;

import dominest.elemento.domino.Domino;
import prof.jogos2D.image.ComponenteAnimado;
import prof.jogos2D.image.ComponenteMultiVisual;
import prof.jogos2D.util.Vector2D;

/**
 * Representa a formiga do jogo
 */
public class Formiga {

	private ComponenteMultiVisual image; // animações da formiga

	/** constantes para a direção da formiga */
	private static final Vector2D DIR_CIMA = new Vector2D( 0, -ConstantesJogo.VELOC_MOV_FORMIGA );  
	private static final Vector2D DIR_BAIXO = new Vector2D( 0, ConstantesJogo.VELOC_MOV_FORMIGA );  
	private static final Vector2D DIR_ESQUERDA = new Vector2D( -ConstantesJogo.VELOC_MOV_FORMIGA, 0 );  
	private static final Vector2D DIR_DIREITA = new Vector2D( ConstantesJogo.VELOC_MOV_FORMIGA, 0 );  
	private static final Vector2D DIR_NAO_MOVE = new Vector2D( 0, 0 );
	
	private Vector2D direcao;            // direção do movimento  
	private Point2D.Double posicao;      // posição atual
	private Point2D.Double posicaoFinal; // posição de destino
	
	private Domino carregado;            // dominó que carrega	
	private double offsetDomino = 0;     // distância da formiga ao dominó que carrega 
	
	private Plataforma plataforma, plataformaUltima; // plataforma onde está e de onde saiu
	
	private Nivel nivel;  // nível onde a formiga se movimenta 
	
	/** constantes para identificar a ação que a formiga está a executar */
	public static final int PARADA = 0;
	public static final int ANDAR = 1;
	public static final int PEGAR = 2;
	public static final int REPOR = 3;
	public static final int POUSAR = 4;
	public static final int ESCADAS = 5;
	public static final int DEBRUCAR = 6;
	public static final int CAIR = 7;
	public static final int EMPURRAR = 9;
	
	/** direção na qual ela está a fazer a ação (empurrar, por exemplo)*/
	public static final int SEM_DIR= -1;
	public static final int ESQUERDA = 0;
	public static final int DIREITA = 1;

	// qual a ação a executar e a direção dessa ação
	private int status = PARADA, statusDir;
	
	// coordenada de onde começou a cair
	private int yQueda;
	
	// indica se a formiga já empurrou
	private boolean empurrou = false;
	
	/** cria a formiga
	 * @param p plataforma inicial
	 * @param img animações 
	 */
	public Formiga( Plataforma p, ComponenteMultiVisual img ) {
		image = img;
		image.setVisualAtual("parada");
		posicionaNaPlataforma( p );
		direcao = DIR_NAO_MOVE;
	}

	/** posiciona-se na plataforma
	 * @param p plataforma onde se posicionar
	 */
	private void posicionaNaPlataforma(Plataforma p) {
		Point pos = new Point( p.getPosicao().x, p.getPosicao().y + ConstantesJogo.OFFSET_FORMIGA_PLAT );
		image.setPosicaoCentro(pos);
		posicao = new Point2D.Double( pos.x, pos.y );
		plataforma = p;
	}
	
	/**
	 * atualizar a formiga 
	 */
	public void atualizar() {
		switch( status ) {
		case PEGAR:
		case REPOR: processaPegarRepor(); break;
		case EMPURRAR: processaEmpurrar(); break;
		case ANDAR:	processaAndar(); break;
		case DEBRUCAR: processaDebrucar();break;
		case CAIR: processaCair(); break;
		case ESCADAS: processaEscadas(); break;
		}
	}

	/** atualiza a formiga quando está a ppegar ou repor um dominó
	 */
	private void processaPegarRepor() {
		// se já fez a animação de pegar/repor passar para parada
		if( image.numCiclosFeitos() >= 1 ) {
			image.reset();
			carregado.mover();		// dizer ao dominó que se vai mover			
			if( status == REPOR ) {
				plataforma.setDomino( carregado );
				carregado = null;							
			}
			else {
				carregado.deslocar( 0, -ConstantesJogo.OFFSET_DOMINO_CARREGADO );
			}
			status = PARADA;
			if( carregado == null  )
				image.setVisualAtual( "parada" );
			else
				image.setVisualAtual( "paradaC" );
		}
	}

	/** atualiza a formiga quando está a empurrar
	 */
	private void processaEmpurrar() {
		ComponenteAnimado img = (ComponenteAnimado)image.getComponenteVisualAtual();
		if( img.getFrameNum() == ConstantesJogo.FRAME_FORMIGA_EMPURRA ) {
			if( statusDir == DIREITA)
				plataforma.getDomino().empurrarDir();
			else if( statusDir == ESQUERDA )
				plataforma.getDomino().empurrarEsq();
			statusDir = SEM_DIR;
		}
		// se a animação de empurrar já acabou
		if( img.numCiclosFeitos() >= 1 ) {
			img.reset();
			if( statusDir == ESQUERDA ) {
				Point p = new Point( image.getPosicao().x-ConstantesJogo.OFFSET_EMPURRAR_ESQ, image.getPosicao().y );
				image.setPosicao(p);
			}
			status = PARADA;
			image.setVisualAtual("parada");
		}
	}
	
	/** atualiza a formiga quando está a andar
	 */
	private void processaAndar() {
		direcao.deslocaPonto( posicao );
		// se já chegou ao destino
		if( posicao.equals( posicaoFinal) ) {
			status = PARADA;					
			if( carregado == null  )
				image.setVisualAtual( "parada" );
			else {
				image.setVisualAtual( "paradaC" );
				carregado.deslocar( -offsetDomino, 0);
				offsetDomino = 0;
			}				
		}
		Point cf = new Point((int)posicao.x,(int)posicao.y);
		image.setPosicaoCentro( cf );
		if( carregado != null ) {
			carregado.deslocar( direcao.x, direcao.y );
		}
	}

	/** atualiza a formiga quando se está a debruçar sobre o abismo
	 */
	private void processaDebrucar() {
		direcao.deslocaPonto( posicao );
		Point cf = new Point((int)posicao.x,(int)posicao.y);
		image.setPosicaoCentro( cf );
		if( carregado != null ) {
			carregado.deslocar( direcao.x, direcao.y );
		}
		// se já chegou à borda da plataforma
		if( posicao.equals( posicaoFinal) ) {
			image.reset();
			Point ps;
			if( direcao.x > 0 )
				ps = plataforma.getPosicaoSaidaDir();
			else
				ps = plataforma.getPosicaoSaidaEsq();
			posicao = new Point2D.Double( ps.x, ps.y );
			cair();
		}
	}
	
	/** atualiza a formiga quando está a cair
	 */
	private void processaCair() {
		direcao.deslocaPonto( posicao );
		Point cf = new Point((int)posicao.x,(int)posicao.y);
		image.setPosicaoCentro( cf );
		// se já chegou à plataforma de destino
		if( plataforma != null && posicao.y - ConstantesJogo.OFFSET_FORMIGA_PLAT >= plataforma.getPosicao().y ) {
			status = PARADA;
			posicionaNaPlataforma( plataforma );
			direcao = DIR_NAO_MOVE;
			image.setVisualAtual( "parada" );
			// ver se a queda foi alta o suficiente para a matar
			int alturaQueda = plataforma.getPosicao().y - yQueda;
			if( alturaQueda > ConstantesJogo.ALTURA_MAXIMA_QUEDA )
				nivel.perdeNivel( "A formiga morreu!" );
		}
		// se já caiu pelo fundo do écran
		else if( plataforma == null && posicao.y - ConstantesJogo.OFFSET_FORMIGA_PLAT >= ConstantesJogo.FUNDO_JOGO ){
			nivel.perdeNivel( "A formiga morreu!" );
		}
	}
	
	/** atualiza a formiga quando está a subir/descer escadas
	 */
	private void processaEscadas() {
		direcao.deslocaPonto( posicao );
		// se já chegou ao topo/fundo
		if( posicao.equals( posicaoFinal) ) {
			status = PARADA;					
			if( carregado == null  )
				image.setVisualAtual( "parada" );
			else {
				image.setVisualAtual( "paradaC" );
				carregado.deslocar( ConstantesJogo.OFFSET_DOMINO_ESCADAS, 0);
				offsetDomino = 0;
			}				
		}
		Point cf = new Point((int)posicao.x,(int)posicao.y);
		image.setPosicaoCentro( cf );
		if( carregado != null ) {
			carregado.deslocar( direcao.x, direcao.y );
		}
	}

	/** vai fazer com a formiga caia
	 */
	public void cair() {
		direcao = DIR_BAIXO; 
		Point cf = new Point((int)posicao.x,(int)posicao.y);
		image.setPosicaoCentro( cf );
		yQueda = plataforma.getPosicao().y;
		plataforma = nivel.getPlataformaAbaixo( cf );		
		image.setVisualAtual( "cair" );
		status = CAIR;
		// se está carregada, vai deixar cair o dominó
		if( carregado != null ) {
			carregado.setPosicao( (Point2D.Double)posicao.clone() );
			carregado.cair( plataforma );
			carregado = null;		
		}
	}

	/** método para fazer com que a formiga pegue ou largue num dominó
	 */
	public void pegar( ) {
		if( status != PARADA )
			return;
		
		// se não está carregada, vai tentar pegar
		if( carregado == null ) {
			if( !plataforma.temDomino() || !plataforma.getDomino().podeSerPegado())
				return;
			
			image.setVisualAtual( "pegar" );
			carregado = plataforma.getDomino();
			carregado.pegar( this );
			plataforma.setDomino( null );
			status = PEGAR;
		}
		// se está carregada, vai tentar pousar o que tem
		else {
			if( !plataforma.aceitaDomino() )
				return;
			
			status = REPOR;
			carregado.deslocar( 0, ConstantesJogo.OFFSET_DOMINO_CARREGADO );
			carregado.pegar( null );
			image.setVisualAtual( "largar" );
		}
	}

	/** faz a formiga andar para a esquerda 
	 */
	public void andarEsquerda() {
		// ver qual a próxima posição para ver se é para parar ou para continuar
		Point2D.Double proxPos = new Point2D.Double( posicao.x+direcao.x, posicao.y + direcao.y );
		boolean continua = status == ANDAR && proxPos.equals( posicaoFinal) && direcao.x < 0;
		if( !continua && status != PARADA )
			return;

		direcao = DIR_ESQUERDA;

		// se não tem plataforma à esquerda vai-se debruçar e depois cair
		if( plataforma.getAnterior() == null ) {
			status = DEBRUCAR;
			Point ps = plataforma.getPosicao();
			posicaoFinal = new Point2D.Double( ps.x - plataforma.getComprimento(), posicao.y );
			return;
		}
		
		// se tem plataforma anterior, calcula até onde tem de caminhar
		plataforma = plataforma.getAnterior().getAnterior();		
		posicaoFinal = new Point2D.Double( plataforma.getPosicao().x, posicao.y );
		
		// se é para continuar a mover, não vale a pena mudar de visual
		if( continua )
			return;
		status = ANDAR;
		if( carregado == null ) 
			image.setVisualAtual( "andarE" );
		else {
			image.setVisualAtual( "carregarE" );
			offsetDomino = -ConstantesJogo.OFFSET_DOMINO_CARREGADO_ESQ;
			carregado.deslocar( offsetDomino, 0);
		}
	}

	/** faz a formiga andar para a direita 
	 */
	public void andarDireita() {
		// ver qual a próxima posição para ver se é para parar ou para continuar
		Point2D.Double proxPos = new Point2D.Double( posicao.x+direcao.x, posicao.y + direcao.y );
		boolean continua = status == ANDAR && proxPos.equals( posicaoFinal) && direcao.x > 0 ;
		if( !continua && status != PARADA )
			return;
		
		direcao = DIR_DIREITA;		
		
		// se não tem plataforma à direita vai-se debruçar e depois cair
		if( plataforma.getProxima() == null ) {
			status = DEBRUCAR;
			
			Point ps = plataforma.getPosicao();
			posicaoFinal = new Point2D.Double( ps.x + plataforma.getComprimento(), posicao.y );
			return;
		}
		
		// se tem plataforma à direita, calcula até onde tem de caminhar
		plataforma = plataforma.getProxima().getProxima();
		posicaoFinal = new Point2D.Double( plataforma.getPosicao().x, posicao.y );

		// se é para continuar a mover, não vale a pena mudar de visual
		if( continua )
			return;

		status = ANDAR;
		offsetDomino = 0;
		if( carregado == null )
			image.setVisualAtual( "andar" );
		else
			image.setVisualAtual( "carregar" );
	}

	/** faz a formiga empurrar o dominó para a esquerda */
	public void empurrarEsq(  ) {
		if( empurrou || status != PARADA )
			return;
		
		if( plataforma.temDomino() ) {
			status = EMPURRAR;
			statusDir = ESQUERDA;
			empurrou = true;
			image.setVisualAtual( "empurrarE" );	
			Point p = new Point( image.getPosicao().x+ConstantesJogo.OFFSET_EMPURRAR_ESQ, image.getPosicao().y );
			image.setPosicao(p);
		}
	}
	
	/** faz a formiga empurrar o dominó para a esquerda */
	public void empurrarDir(  ) {
		if( empurrou || status != PARADA )
			return;
		
		if( plataforma.temDomino() ) {
			status = EMPURRAR;
			statusDir = DIREITA;
			empurrou = true;
			image.setVisualAtual( "empurrarD" );
		}
	}
	
	/** faz a formiga subir escadas */
	public void subir() {
		// se já está nas escadas, mas a descer, então volta para cima
		if( status == ESCADAS && direcao == DIR_BAIXO ) {
			direcao = DIR_CIMA;
			Plataforma p = plataformaUltima; 
			plataformaUltima = plataforma;
			plataforma = p;

			posicaoFinal = new Point2D.Double( posicao.x, plataforma.getPosicao().y+ConstantesJogo.OFFSET_FORMIGA_PLAT );
		}	
		// se está parada é para começar a subir
		else if( status == PARADA ) {
			// ver se onde está tem alguma escada
			Point pe = new Point( (int)posicao.x + plataforma.getComprimento()/2, (int)(posicao.y - ConstantesJogo.OFFSET_FORMIGA_PLAT));
			Escada e = nivel.getEscadaAt( pe );

			// se não tiver escadas, não faz nada
			if( e == null )
				return;
			
			// ver qual a plataforma acima
			Plataforma p = nivel.getPlataformaAcima( pe );
			// se não houver plataforma acima, não sobe
			if( p == null || !e.estaDentro(p.getPosicao()) )
				return;
			
			status = ESCADAS;
			direcao = DIR_CIMA;
			plataformaUltima = plataforma;
			plataforma = p;
			if( carregado == null )
				getImage().setVisualAtual("subir");
			else {
				getImage().setVisualAtual("subirC");
				carregado.deslocar(-ConstantesJogo.OFFSET_DOMINO_ESCADAS, 0);
			}

			// calcula a posição do topo das escadas
			posicaoFinal = new Point2D.Double( posicao.x, plataforma.getPosicao().y+ConstantesJogo.OFFSET_FORMIGA_PLAT );			
		}
	}

	/** faz a formiga descer escadas */
	public void descer() {
		// se já está nas escadas, mas a subir, então volta para baixo
		if( status == ESCADAS && direcao == DIR_CIMA ) {
			direcao = DIR_BAIXO;
			Plataforma p = plataformaUltima; 
			plataformaUltima = plataforma;
			plataforma = p;

			posicaoFinal = new Point2D.Double( posicao.x, plataforma.getPosicao().y+ConstantesJogo.OFFSET_FORMIGA_PLAT );

		}	
		// se está parada é para começar a subir
		else if( status == PARADA ) {
			// ver se onde está tem alguma escada
			Point pe = new Point( (int)posicao.x + plataforma.getComprimento()/2, (int)(posicao.y - ConstantesJogo.OFFSET_FORMIGA_PLAT));
			Escada e = nivel.getEscadaAt( pe );
			
			// se não tiver, não desce
			if( e == null ) 
				return;
			
			// ver qual a plataforma abaixo
			Plataforma p = nivel.getPlataformaAbaixo( pe );
			
			// se não houver plataforma abaixo, não desce
			if( p == null || !e.estaDentro(p.getPosicao()) )
				return;
			
			if( carregado == null)
				getImage().setVisualAtual("descer");
			else {
				getImage().setVisualAtual("descerC");
				carregado.deslocar(-ConstantesJogo.OFFSET_DOMINO_ESCADAS, 0);
			}
			status = ESCADAS;
			direcao = DIR_BAIXO;
			plataformaUltima = plataforma;
			plataforma = p;
			// calcula a posição do fundo das escadas
			posicaoFinal = new Point2D.Double( posicao.x, plataforma.getPosicao().y+ConstantesJogo.OFFSET_FORMIGA_PLAT );
		}
	}

	
	/** define o nível onde a formiga se movimenta 
	 * @param nivel o nível onde se movimenta
	 */
	public void setNivel(Nivel nivel) {
		this.nivel = nivel;
	}
	
	/** retorna o nível onde a formiga se movimenta
	 * @return o nível onde a formiga se movimenta
	 */
	public Nivel getNivel() {
		return nivel;
	}

	/** retorna o dominó que a formiga carrega
	 * @return o dominó que a formiga carrega, null se não carrega nenhum
	 */
	public Domino getCarregado() {
		return carregado;
	}
	
	/** Desenha a formiga 
	 * @param g ambiente onde desenhar a formiga
	 */
	public void desenhar( Graphics2D g ){
		image.desenhar(g);
	}
		
	/** retorna a posição da formiga (centro da mesma) em coordenadas de ecran
	 * @return a posição da formiga em pixeis
	 */
	public Point getPosicaoPoint() {
		return new Point( (int)posicao.x, (int)posicao.y );
	}

	/** retorna a plataforma onde se encontra
	 * @return a plataforma onde se encontra
	 */
	public Plataforma getPlataforma() {
		return plataforma;
	}
	
	/** altera a plataforna onde a formiga se encontra
	 * @param plataforma onde vai ser colocada 
	 */
	public void setPlataforma(Plataforma plataforma) {
		posicionaNaPlataforma( plataforma );
	}
	
	/**
	 * retorna as animações da formiga
	 * @return as animações da formiga
	 */
	public ComponenteMultiVisual getImage() {
		return image;
	}
	
	/** devolve o vetor de direção
	 * @return  o vetor de direção
	 */
	public Vector2D getDirecao() {
		return direcao;
	}	
}