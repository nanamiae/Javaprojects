package dominest.elemento;

import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.geom.Point2D;

import dominest.elemento.domino.Domino;
import prof.jogos2D.image.ComponenteMultiVisual;

/** Classe que representa uma plataforma no jogo. <br>
 * Uma plataforma pode ou não suportar um dominó. Cada plataforma
 * só pode ter um único dominó. <br>
 * Tem uma indicação de qual a próxima ou a anterior, caso esteja ligada. 
 *  
 * @author F. Sergio Barbosa
 */
public class Plataforma {

	private Point posicao;   // posição da plataforma
	private int imgOffset;   // diferença entre a posição da plataforma e a sua imagem 
	private int comprimento;  
	private ComponenteMultiVisual image;
	
	private Domino domino;           // o dominó que está na plataforma (se algum)
	private boolean aceitaDomino;    // a plataforma aceita dominó?
	
	// A plataforma seguinte e a anterior
	private Plataforma proxima, anterior;
	
	/** constroi uma plataforma
	 * @param posicao posição no jogo (inicio e chão)
	 * @param imgOffset diferença entre a posição no jogo e a posição da imagem
	 * @param comprimento comprimento da pataforma
	 * @param image imagem associada
	 * @param aceita indica se a plataforma aceita ou não dominó
	 */
	public Plataforma(Point posicao, int imgOffset, int comprimento, ComponenteMultiVisual image, boolean aceita ) {
		this.comprimento = comprimento;
		this.image = image;
		this.aceitaDomino = aceita;
		this.imgOffset = imgOffset;
		setPosicao( posicao );		
	}
	
	/** retorna a plataforma imediatamente à direita desta
	 * @return a plataforma imediatamente à direita desta
	 */
	public Plataforma getProxima() {
		return proxima;
	}

	/** define a plataforma imediatamente à direita desta
	 * @param proxima a plataforma imediatamente à direita desta
	 */
	public void setProxima(Plataforma proxima) {
		this.proxima = proxima;
		decideImagem();
	}

	/** retorna a plataforma imediatamente à esquerda desta
	 * @return a plataforma imediatamente à esquerda desta
	 */
	public Plataforma getAnterior() {
		return anterior;
	}

	/** define a plataforma imediatamente à esquerda desta
	 * @param anterior a plataforma imediatamente à esquerda desta
	 */
	public void setAnterior(Plataforma anterior) {
		this.anterior = anterior;
		decideImagem();
	}

	/** sempre que se adiciona/retira uma pataforma contigua
	 * é preciso decidir qual a imagem que a plataforma vai ter
	 */
	private void decideImagem() {
		if( anterior == null && proxima == null )
			image.setVisualAtual( "isolada" );
		else if( anterior == null )
			image.setVisualAtual( "inicial" );
		else if( proxima == null )
			image.setVisualAtual( "final" );
		else
			image.setVisualAtual( "meio" );
	}

	/** desenha a plataforma
	 * @param g ambiente gráfico onde desenhar
	 */
	public void desenhar( Graphics2D g ) {
		image.desenhar( g );
		/* para debug, mostra a linha do chão da plataforma
		g.setColor( Color.cyan );
		g.drawLine(posicao.x, posicao.y, posicao.x + comprimento, posicao.y);
		*/
	}

	/** devolve a posição: x do inicio e y do chão
	 * @return a posição da plataforma
	 */
	public Point getPosicao() {
		return posicao;
	}

	/** define  a posição: x do inicio e y do chão
	 * @param posicao a posição da plataforma
	 */
	public void setPosicao(Point posicao) {
		this.posicao = (Point)posicao.clone();
		image.setPosicao( new Point( this.posicao.x, this.posicao.y - imgOffset ) );
	}
	
	/** devolve o ponto onde as coisas começam a cair da plataforma pela sua direita
	 * @return o ponto onde as coisas começam a cair da plataforma pela sua direita
	 */
	public Point getPosicaoSaidaDir() {
		return new Point( posicao.x + 2*comprimento + 1, posicao.y );
	}
	
	/** devolve o ponto onde as coisas começam a cair da plataforma pela sua esquerda
	 * @return o ponto onde as coisas começam a cair da plataforma pela sua esquerda
	 */
	public Point getPosicaoSaidaEsq() {
		return new Point( posicao.x - comprimento - 1 , posicao.y );
	}

	/** retorna o comprimento da plataforma
	 * @return o comprimento da plataforma
	 */
	public int getComprimento() {
		return comprimento;
	}

	/** define o comprimento da plataforma
	 * @param comprimento o comprimento da plataforma
	 */
	public void setComprimento(int comprimento) {
		this.comprimento = comprimento;
	}

	/** devolve a imagem da plataforma
	 * @return a imagem da plataforma
	 */
	public ComponenteMultiVisual getImage() {
		return image;
	}

	/** define a imagem da plataforma
	 * @param image a imagem da plataforma
	 */
	public void setImage(ComponenteMultiVisual image) {
		this.image = image;
	}

	/** devolve o dominó presente, se algum
	 * @return o dominó presente, ou null se não tiver nenhum
	 */
	public Domino getDomino() {
		return domino;
	}

	/** Coloca um dominó na plataforma. Se já lá estiver um, substitui. 
	 * Se o novo for null significa que se vai remover o que lá está.
	 * @param domino dominó a colocar na plataforma, null se for para remover 
	 */
	public void setDomino(Domino domino) {
		// se já lá tem um, dizer-lhe que já lá não está
		if( this.domino != null) {
			this.domino.setPlataforma( null );
		}
		this.domino = domino;
		if( domino != null ) {
			// posicionar o dominó no local certo
			domino.setPosicao( new Point2D.Double( posicao.x+ConstantesJogo.OFFSET_DOMINO_PLATAFORMA_X,
					                               posicao.y-ConstantesJogo.OFFSET_DOMINO_PLATAFORMA_Y ) );
			domino.setPlataforma( this );
		}
	}

	/** indica se aceita dominó
	 * @return true, se aceita dominó
	 */
	public boolean aceitaDomino() {
		return aceitaDomino && !temDomino();
	}

	/** define se a plataforma aceita dominós
	 * @param aceitaDomino true para dizer que aceita
	 */
	public void setAceitaDomino(boolean aceitaDomino) {
		this.aceitaDomino = aceitaDomino;
	}

	/** indica se tem dominó
	 * @return true se tiver
	 */
	public boolean temDomino() {
		return domino != null;
	}
	
	/** indica se uma dada coordenda está dentro da área da plataforma
	 * @param pt a coordenada a testar
	 * @return true, se a coordenada está dentro da área da plataforma 
	 */
	public boolean estaDentro( Point pt ) {
		return posicao.x <= pt.x && posicao.x + comprimento >= pt.x &&
			   posicao.y-15 <= pt.y && posicao.y + 15 >= pt.y; 
	}
	
	/** devolve o offset da imagem
	 * @return o offset da imagem
	 */
	public int getImageOffset() {
		return imgOffset;
	}
	
	/** define o offset a dar à imagem
	 * @param imgOffset o offset da imagem
	 */
	public void setImageOffset(int imgOffset) {
		this.imgOffset = imgOffset;
	}
	
	@Override
	public String toString() {
		return posicao.toString();
	}
}
