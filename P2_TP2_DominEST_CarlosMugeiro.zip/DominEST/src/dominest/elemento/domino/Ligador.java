package dominest.elemento.domino;

import java.awt.Point;
import java.awt.geom.Point2D;

import dominest.elemento.ConstantesJogo;
import dominest.elemento.Plataforma;
import prof.jogos2D.image.ComponenteMultiVisual;

public class Ligador extends Domino {

	public Ligador(ComponenteMultiVisual c) {
		super(c);
		// TODO Auto-generated constructor stub
	}




	/** Faz com que o dominó caia */
	protected void cair( ) {

		// ver se há uma plataforma à distância de no máximo 4 plataformas
		// basta ver a 2, 3 e 4
		int comp = getPlataforma().getComprimento();
		// ponto no meio da plataforma
		Point pMeio = new Point( getPlataforma().getPosicao().x + comp/2, getPlataforma().getPosicao().y);
		int sinal = getAcao() == TOMBAR_DIR? 1: -1;
		int dist = 2;
		Plataforma plat;
		Point pTeste = (Point)pMeio.clone();
		do {
			pTeste.x = pMeio.x + dist*comp*sinal;
			plat = getNivel().getPlataformaAt( pTeste );
			if( plat != null )
				break;
			dist++;
		} while( dist < 5 );
		if( plat != null ) {
			// há uma plataforma à distãncia máxima
			// criar as plataformas no local certo
			int xi = (int)(getAcao() == TOMBAR_DIR? getPlataforma().getPosicao().x+comp:
				getPlataforma().getPosicao().x-comp);
			int offset = getPlataforma().getImageOffset();
			ComponenteMultiVisual cv = getPlataforma().getImage();
			for( int i = 0; i < dist-1; i++) {
				Point pos = new Point( xi + i*sinal*comp, pMeio.y );				
				Plataforma p = new Plataforma(pos, offset, comp, cv.clone(), i%2==1);
				getNivel().addPlataforma( p );
			}
			getPlataforma().setDomino( null );
			getNivel().removeDomino( this );
		}
		// se não houver plataformas para criar, cai normalmente
		else 
			super.cair();

	}

}
