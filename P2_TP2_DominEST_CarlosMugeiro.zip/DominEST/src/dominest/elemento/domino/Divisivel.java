package dominest.elemento.domino;

import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.geom.Point2D;

import dominest.elemento.Plataforma;
import prof.jogos2D.image.ComponenteAnimado;
import prof.jogos2D.image.ComponenteMultiVisual;

public class Divisivel extends Domino {


	// Variáveis para o dominó Divisível
	private boolean partiu;       // se já se partiu
	private ComponenteAnimado c2; // animação para o que se vai dividir 


	public Divisivel(  ComponenteMultiVisual c) {
		super(  c);

		// copiar o componente animado referente à animação de tombar
		// apenas necessário por causa do divísivel
		c2 = (ComponenteAnimado)c.getComponenteVisual("tombar").clone();
	}

	/** desenha o dominó no ambiente gráfico
	 * @param g onde desenhar
	 */
	@Override
	public void desenhar(Graphics2D g) {
		// desenharnormal, comum a todos
		super.desenhar(g);
		if( partiu ) {
			int frameNum = (180-getAngulo()) / deltaAngulo;
			c2.setFrameNum( frameNum );
			c2.desenhar(g);
		}
	}

	/** método chamado quando outro dominó cai em cima deste
	 * @param d o dominó que cai em cima deste
	 */
	@Override
	public void bateCima(Domino d) {
		// se bateu em cima de um divisível, então o comportamento é diferente
		// se já partiu, não volta a prtir logo porta-se como um normal
		if( partiu ) 
			super.bateCima(d);
		else {
			Plataforma plat = getPlataforma();
			getNivel().removeDomino( d );
			getNivel().removeDomino( this );

			//empurrarDir();
			Domino d1 = new Normal( getImagem().clone() );
			getNivel().addDomino( d1 );
			Domino d2 = new Normal(  getImagem().clone() );
			getNivel().addDomino( d2 );
			// só um irá ficar, mas colocam-se os dois na plataforma
			plat.setDomino( d1 );
			plat.setDomino( d2 );
			// e força-se o primero a usar a mesma plataforma
			d1.setPlataforma( plat );
			partiu = true;
			d1.empurrarDir();
			d2.empurrarEsq();
		}
	}


	/** define a posição do dominó
	 * @param pt a posição onde colcoar o dominó 
	 */
	@Override
	public void setPosicao(Point2D.Double pt ) {
		super.setPosicao(pt); 
		c2.setPosicaoCentro( new Point((int)pt.x,(int)pt.y) );
	}



}
