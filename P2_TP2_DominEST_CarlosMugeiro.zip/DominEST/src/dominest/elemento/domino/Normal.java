package dominest.elemento.domino;

import prof.jogos2D.image.ComponenteMultiVisual;

public class Normal  extends Domino{

	public Normal( ComponenteMultiVisual c) {
		super(c);
		// TODO Auto-generated constructor stub
	}
}
