package dominest.elemento.domino;

import prof.jogos2D.image.ComponenteMultiVisual;

public class Desaparece extends Domino {

	public Desaparece( ComponenteMultiVisual c) {
		super( c);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void atualiza() {
		super.atualiza();
		
		//veriricar se caiu, se sim, desaparece
		if(estaTombado()) {
			getNivel().removeDomino( this );
		}
	}

}
