package dominest.elemento.domino;

import dominest.elemento.Plataforma;
import prof.jogos2D.image.ComponenteMultiVisual;

public class Continuo extends Domino {



	// variável para um dominó contínuo, que armazena
	// a ação de tombar que está a fazer
	private int acaoTombar = SEM_ACAO;


	public Continuo( ComponenteMultiVisual c) {
		super( c);
		// TODO Auto-generated constructor stub
	}

	/** atualiza a posição e o ângulo do dominó
	 */
	@Override
	public void atualiza( ){
		super.atualiza();
		if( estaCompletamenteTombado() ) {
			// se está completamente tombado é porque
			// está numa plataforma com plataforma a seguir
			// e sem dominós a seguir
			if( getAcao() == TOMBAR_DIR ) {
				Plataforma dest = getPlataforma().getProxima().getProxima();
				Plataforma atual = getPlataforma(); 
				atual.setDomino( null );
				if( dest != null )
					dest.setDomino( this );
				setAngulo( 180 );
				empurrarDir();
			}				
			else {
				Plataforma dest = getPlataforma().getAnterior().getAnterior();
				Plataforma atual = getPlataforma(); 
				atual.setDomino( null );
				if( dest != null )
					dest.setDomino( this );
				setAngulo( 0 );
				empurrarEsq();
			}
		}
	}

	/** processa um empurrão para a direita
	 */
	@Override
	public void empurrarDir() {
		// se não está em pé, não pode ser empurrado
		if( !estaPe() )
			return;

		acaoTombar = TOMBAR_DIR;

		super.empurrarDir();
	}

	/** processa um empurrão para a esquerda
	 */
	@Override
	public void empurrarEsq() {
		// se não está em pé, não pode ser empurrado
		if( !estaPe() )
			return; 

		acaoTombar = TOMBAR_ESQ;

		super.empurrarEsq();
	}


	/** define a plataforma onde vai passar a estar
	 * @param plataforma plataforma onde vai ficar
	 */
	@Override
	public void setPlataforma(Plataforma plataforma) {
		super.setPlataforma(plataforma);


		// se não tem pataforma não faz nada
		if( plataforma == null )
			return;
		// por algum motivo (caiu ou outro) parou
		if( getAcao() != TOMBAR_DIR && getAcao() != TOMBAR_ESQ && acaoTombar != SEM_ACAO ) {
			// senão continuar a tombar
			if( acaoTombar == TOMBAR_DIR )
				empurrarDir();
			else
				empurrarEsq();
		}

	}

}
