package dominest.elemento.domino;

import prof.jogos2D.image.ComponenteMultiVisual;

public class Parede extends Domino{

	public Parede( ComponenteMultiVisual c) {
		super( c);
		// TODO Auto-generated constructor stub
	}

	
	/** método chamado quando outro dominó baste neste do lado direito
	 * @param d o dominó que bate neste
	 */
	@Override
	public void bateLadoDir(Domino d) {
		// se baterem no lado direito é como se fosse empurrado para a esquerda 
		d.setAngulo(90);
		d.empurrarDir();
		 
	}
	
	/** método chamado quando outro dominó baste neste do lado esquerdo
	 * @param d o dominó que bate neste
	 */
	@Override
	public void bateLadoEsq(Domino d) {
		// se baterem no lado esquerdo é como se fosse empurrado para a direita
		d.setAngulo(90);
		d.empurrarEsq();
	}
	

	@Override
	public void empurrarEsq() {
		
	}

	@Override
	public void empurrarDir() {
		
	}
	
	@Override
	public boolean estaTerminado() {	
		return true;
	}
	
	
}
