package dominest.elemento.domino;

import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.geom.Point2D;

import dominest.elemento.Formiga;
import dominest.elemento.Nivel;
import dominest.elemento.Plataforma;
import prof.jogos2D.image.ComponenteMultiVisual;

public interface InterfaceDomino {

	// constantes para os ângulos predefinidos de embate e de estar suspenso 
	public  final int ANGULO_BATERE = 140;
	public  final int ANGULO_BATERD = 40;
	public  final int ANGULO_SUSPENSOE = 170;
	public  final int ANGULO_SUSPENSOD = 10;
	public  final int deltaAngulo = 10;


	// constantes para as ações que o dominó pode fazer
	public  final int SEM_ACAO = -1;
	public  final int PARADO = 0;
	public  final int TOMBAR_ESQ = 1;
	public  final int TOMBAR_DIR = 2;
	public  final int PEGAR = 3;
	public  final int CAIR = 4;


	/** desenha o dominó no ambiente gráfico
	 * @param g onde desenhar
	 */
	void desenhar(Graphics2D g);

	/** atualiza a posição e o ângulo do dominó
	 */
	void atualiza();

	/** atualização de um dominó contínuo. <br>
	 * Tem de verificar se é para continuar a tombar
	 */
	//void atualizaContinuo();

	/** Indica ao dominó que vai cair para uma dada plataforma
	 * @param plat plataforma para onde vai cair
	 */
	void cair(Plataforma plat);

	/** método chamado quando outro dominó cai em cima deste
	 * @param d o dominó que cai em cima deste
	 */
	void bateCima(Domino d);

	/** método chamado quando outro dominó baste neste do lado direito
	 * @param d o dominó que bate neste
	 */
	void bateLadoDir(Domino d);

	/** método chamado quando outro dominó baste neste do lado esquerdo
	 * @param d o dominó que bate neste
	 */
	void bateLadoEsq(Domino d);

	/** método que é chamado quando a formiga pega nele
	 * @param formiga a formiga que pegou no dominó
	 */
	void pegar(Formiga formiga);

	/** indica ao dominó que se vai mover
	 */
	void mover();

	/** processa um empurrão para a esquerda
	 */
	void empurrarEsq();

	/** processa um empurrão para a esquerda num dominó elevador
	 */
	//void empurrarEsqElevador();

	/** processa um empurrão para a direita
	 */
	void empurrarDir();

	/** indica se o dominó está em pé
	 * @return true, se está em pé
	 */
	boolean estaPe();

	Domino getDominoDir();

	Domino getDominoEsq();

	/** indica se o dominó pode ser pegado
	 * @return true se o dominó pode ser pegado
	 */
	boolean podeSerPegado();

	/** define a plataforma onde vai passar a estar
	 * @param plataforma plataforma onde vai ficar
	 */
	void setPlataforma(Plataforma plataforma);

	/** retorna a plataforma onde está.
	 * @return a plataforma onde está.
	 */
	Plataforma getPlataforma();

	/** retorna a posição do dominó
	 * @return  a posição do dominó
	 */
	Point2D.Double getPosicao();

	/** define a posição do dominó
	 * @param pt a posição onde colcoar o dominó 
	 */
	void setPosicao(Point2D.Double pt);

	/** desloca numa dada direção
	 * @param dx deslocamento em x
	 * @param dy deslocamento em y
	 */
	void deslocar(double dx, double dy);

	Nivel getNivel();

	void setNivel(Nivel nivel);

	boolean estaTerminado();

	/** Indica se o dominó está tombado.
	 * <br>Pode não estar completamente tombado se estiver caido sobre outro dominó)
	 * @return true, se estiver tombado
	 */
	boolean estaTombado();

	/** Indica se o dominó está completamente tombado
	 * @return true, se estiver completamente tombado
	 */
	boolean estaCompletamenteTombado();

	/** retorna o ângulo de inclinação (entre 0 e 180)
	 * @return o ângulo de inclinação 
	 */
	int getAngulo();

	ComponenteMultiVisual getImagem();

	void setImagem(ComponenteMultiVisual img);

	Point getPosicaoImagem();

	void setPosicaoImagem(Point p);

}