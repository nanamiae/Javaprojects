package dominest.elemento.domino;

import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.geom.*;

import dominest.elemento.ConstantesJogo;
import dominest.elemento.Formiga;
import dominest.elemento.Nivel;
import dominest.elemento.Plataforma;
import prof.jogos2D.image.*;
import prof.jogos2D.util.Vector2D;

/** Classe que representa o dominó do jogo.*/
public abstract class Domino implements  InterfaceDomino {

 	// qual o ângulo em que o dominó está e de quanto deve variar o ângulo
	private int angulo = 90, stepAngulo = 0;

	// qual a ação atual e qual a anterior
	private int acao = PARADO, ultimaAcao = SEM_ACAO;
	
	// posicao atual e qual a plataforma onde está
	private Point2D.Double posicao; 	
	private Plataforma plataforma;
	
	// direção em que o dominó se move (usada nas quedas e nas súbidas)
	private Vector2D direcao;
	
	private Nivel nivel;
	private ComponenteMultiVisual imagem; 
 
	/** Constroi um Dominó
	 * @param tipo tipo do dominó (acho que já ficou claro que isto tem de desaparecer, certo?) 
	 * @param c elemento com as várias animações do dominó
	 */ 
 	public Domino(  ComponenteMultiVisual c)  {
	 
		imagem = c;
		direcao = new Vector2D( 1, 0);
		c.setVisualAtual( "tombar" ); 
	}
	
	/** desenha o dominó no ambiente gráfico
	 * @param g onde desenhar
	 */
	@Override
	public void desenhar(Graphics2D g) {
		if( acao != PEGAR ) {
			int frame = angulo / deltaAngulo;
			((ComponenteAnimado)getImagem().getComponenteVisualAtual()).setFrameNum( frame );
		}			
		imagem.desenhar(g); 
	}
 

	
	/** atualiza a posição e o ângulo do dominó
	 */
	@Override
	public void atualiza( ){
		
		//implementação comum (atualizaNormal)
		if( acao == PARADO )
			return;
		
		if( acao == CAIR ) 
			caindo();
		else if( acao == TOMBAR_ESQ || acao == TOMBAR_DIR ) {
			tombar();
		}
 
	} 
	 

	/** atualiza o dominó quando este está a tombar
	 */
	private void tombar() {
		atualizaAngulo();
		if( estaAnguloEmbate() ) {
			// ver se tem uma plataforma onde tombar e se esta tem um dominó em pé
			if( temPlataformaTombar() ) {				
				Domino d = getProximoDomino();
				if( d != null && !d.estaTombado())
					bateDomino(d);
			}
		}				
		else if( estaTombado() ) {
			// se está tombado e não tem onde tombar é porque vai cair!!
			if( !temPlataformaTombar() ) {				
				cair();  
			}
		}
	}

	/** Faz com que o dominó caia */
	protected void cair( ) {
		
		Point p = getPosicaoSaidaPlataforma();
		// se não tem plataforma predestinada, procura uma
		Plataforma plat = getNivel().getPlataformaAbaixo( p );
		setPosicao( new Point2D.Double(p.x+ (getAcao()==TOMBAR_DIR? ConstantesJogo.OFFSET_DOMINO_PLATAFORMA_X: -10), p.y) );
		plataforma.setDomino( null );
		cair( plat );
		 
	} 
	
	/** Indica ao dominó que vai cair para uma dada plataforma
	 * @param plat plataforma para onde vai cair
	 */
	@Override
	public void cair( Plataforma plat ) {
		ultimaAcao = acao;
		setAcao( CAIR );
		direcao = new Vector2D( 0, ConstantesJogo.VELOC_QUEDA_DOMINO );
		plataforma = plat;
		angulo = 90;
		getImagem().setVisualAtual( "tombar" );					
	}
	
	/** Atualiza o dominó enquanto este cai */
	private void caindo() {
		deslocar( direcao.x, direcao.y);
		// ver se já chegou à plataforma
		if( plataforma != null && posicao.y >= plataforma.getPosicao().y - ConstantesJogo.OFFSET_DOMINO_PLATAFORMA_Y ) {
			// repor a ação que estava a fazer antes de cair
			setAcao( ultimaAcao );
			// já não cai mais, coloca a direção a 0
			direcao = new Vector2D(0,0);
			// se a plataforma onde vai cair tem dominó, cai-lhe em cima, senão cai na plataforma
			if( plataforma.temDomino() )
				plataforma.getDomino().bateCima( this );
			else
				plataforma.setDomino( this );
		}
		else if( plataforma == null && posicao.y > ConstantesJogo.FUNDO_JOGO ) {
			getNivel().removeDomino( this );
		}
	}

	/** processar a batida noutro donimó
	 * @param d dominó onde vai bater
	 */
	protected void bateDomino(Domino d) {
		if( acao == TOMBAR_ESQ )
			d.bateLadoDir( this );
		else
			d.bateLadoEsq( this );
	}

	/** método chamado quando outro dominó cai em cima deste
	 * @param d o dominó que cai em cima deste
	 */
	@Override
	public void bateCima(Domino d) {
		
		getNivel().perdeNivel( "Dominó partiu!" ); 
	} 
	
	/** método chamado quando outro dominó baste neste do lado direito
	 * @param d o dominó que bate neste
	 */
	@Override
	public void bateLadoDir(Domino d) {
		// se baterem no lado direito é como se fosse empurrado para a esquerda 
		empurrarEsq();
	}
	
	/** método chamado quando outro dominó baste neste do lado esquerdo
	 * @param d o dominó que bate neste
	 */
	@Override
	public void bateLadoEsq(Domino d) {
		// se baterem no lado esquerdo é como se fosse empurrado para a direita
		empurrarDir();
	}
	
	/** método que é chamado quando a formiga pega nele
	 * @param formiga a formiga que pegou no dominó
	 */
	@Override
	public void pegar(Formiga formiga) {
		setAcao( PEGAR );
		if( formiga != null ) 
			getImagem().setVisualAtual( "pegar" );
		else 
			getImagem().setVisualAtual( "repor" );
	}

	/** indica ao dominó que se vai mover
	 */
	@Override
	public void mover() {
		setAcao( PARADO );
		getImagem().setVisualAtual( "tombar" );
		getImagem().setPosicaoCentro( new Point((int)posicao.x,(int)posicao.y) );
	}

	/** processa um empurrão para a esquerda
	 */
	@Override
	public void empurrarEsq() {
		// se não está em pé, não pode ser empurrado
		if( !estaPe() )
			return; 
		
		setAcao( TOMBAR_ESQ );
		stepAngulo = deltaAngulo;
		 
	} 
	
	/** processa um empurrão para a direita
	 */
	@Override
	public void empurrarDir() {
		// se não está em pé, não pode ser empurrado
		if( !estaPe() )
			return;

		setAcao( TOMBAR_DIR );
		stepAngulo = -deltaAngulo;
		 
	}
	 
	
	/** atualiza o ângulo do dominó
	 */
	protected void atualizaAngulo() {
		// se está suspenso tem de verificar se tem dominó a seguir		
		if( estaAnguloSuspenso() ) {
			if( temPlataformaTombar() ) {
				// se tem dominó a seguir não pode continuar a descer
				Domino d = getProximoDomino();
				if( d != null )
					return;
			}
		}
		angulo += stepAngulo;
		if( angulo < 0 )
			angulo = 0;
		else if( angulo > 180 )
			angulo = 180;
	}
	/** verifica se tem uma plataforma onde tombar
	 * @return true, se tomba numa plataforma
	 */
	protected boolean temPlataformaTombar() {
		if( acao == TOMBAR_ESQ )
			return plataforma.getAnterior() != null;
		else if( acao == TOMBAR_DIR )
			return plataforma.getProxima() != null;
		return false;
	}
	
	/** vê qual o próximo dominó na sequência
	 * @return o próximo dominó na sequência, null se não houver nenhum
	 */
	protected Domino getProximoDomino() {
		if( acao == TOMBAR_DIR ) {
			Plataforma meio = plataforma.getProxima();
			if( meio == null)
				return null;
			Plataforma dest = meio.getProxima();
			return dest != null? dest.getDomino(): null;
		}
		else if( acao == TOMBAR_ESQ ) {
			Plataforma meio = plataforma.getAnterior();
			if( meio == null)
				return null;
			Plataforma dest = meio.getAnterior();
			return dest != null? dest.getDomino(): null;
		}
		return null;
	}

	
	/** indica se o dominó está em pé
	 * @return true, se está em pé
	 */
	@Override
	public boolean estaPe( ) {
		return angulo == 90;
	}
	
	/** indica se o angulo corresponde ao ângulo em que embate no donimó do lado
	 * @return true se estiver no ângulo de embate
	 */
	protected boolean estaAnguloEmbate() {
		return (acao==TOMBAR_DIR && angulo == ANGULO_BATERD) || (angulo == ANGULO_BATERE && acao == TOMBAR_ESQ);
	}

	
	/** indica se o angulo corresponde ao ângulo em que fica suspenso por estar em cima de outro dominó
	 * @return true se estiver no ângulo de suspensão
	 */
	protected boolean estaAnguloSuspenso() {
		return (acao==TOMBAR_DIR && angulo == ANGULO_SUSPENSOD) || (angulo == ANGULO_SUSPENSOE && acao == TOMBAR_ESQ);
	}
	
	@Override
	public Domino getDominoDir() {
		// se não tem plataforma não tem dominó
		if( plataforma == null )
			return null;

		// ver se há duas plataforma à direita
		Plataforma meio = plataforma.getProxima();
		Plataforma dest = meio != null? meio.getProxima(): null;
		
		// se existirem plataformas
		return dest != null? dest.getDomino(): null;
	}
	
	@Override
	public Domino getDominoEsq() {
		// se não tem plataforma não tem dominó
		if( plataforma == null )
			return null;

		// ver se há duas plataforma à esquerda
		Plataforma meio = plataforma.getAnterior();
		Plataforma dest = meio != null? meio.getAnterior(): null;
		
		// se existirem plataformas
		return dest != null? dest.getDomino(): null;
	}
	
	/** indica se o dominó pode ser pegado
	 * @return true se o dominó pode ser pegado
	 */
	@Override
	public boolean podeSerPegado() { 
		return acao == PARADO; // um dominó mesmo completamente tombado está a tombar e não PARADO
	}

	/** posição de onde o dominó cai da plataforma
	 * @return posição de onde o dominó cai da plataforma
	 */
	protected Point getPosicaoSaidaPlataforma() {
		return acao == TOMBAR_DIR? plataforma.getPosicaoSaidaDir(): plataforma.getPosicaoSaidaEsq();
	}
	
	/** define a plataforma onde vai passar a estar
	 * @param plataforma plataforma onde vai ficar
	 */
	@Override
	public void setPlataforma(Plataforma plataforma) {
		this.plataforma = plataforma; 
	}
	
	/** retorna a plataforma onde está.
	 * @return a plataforma onde está.
	 */
	@Override
	public Plataforma getPlataforma() {
		return plataforma;
	}
	
	/** retorna a posição do dominó
	 * @return  a posição do dominó
	 */
	@Override
	public Point2D.Double getPosicao() {
		return posicao;
	}
	
	/** define a posição do dominó
	 * @param pt a posição onde colcoar o dominó 
	 */
	@Override
	public void setPosicao(Point2D.Double pt ) {
		this.posicao = pt;
		getImagem().setPosicaoCentro( new Point((int)posicao.x,(int)posicao.y) ); 
	}
	
	/** define qual a ação que o dominó vai fazer
	 * @param acao a ação que o dominó vai fazer
	 */
	protected void setAcao(int acao) {
		ultimaAcao = this.acao;
		this.acao = acao;
	}

	/** indica qual a ação que o dominó está a fazer
	 * @return qual a ação que o dominó está a fazer
	 */
	protected int getAcao() {
		return acao;
	}
	
	/** indica qual a ultima ação que o dominó fez
	 * @return qual a ultima ação que o dominó fez
	 */
	protected int getUltimaAcao() {
		return ultimaAcao;
	}

	/** desloca numa dada direção
	 * @param dx deslocamento em x
	 * @param dy deslocamento em y
	 */
	@Override
	public void deslocar(double dx, double dy) {		
		posicao.x += dx;
		posicao.y += dy;
		getImagem().setPosicaoCentro( new Point( (int)posicao.x, (int)posicao.y ) );	
	}

	@Override
	public Nivel getNivel() {
		return nivel;
	}

	@Override
	public void setNivel(Nivel nivel) {
		this.nivel = nivel;		
	}

	@Override
	public boolean estaTerminado() {	
		return estaTombado();
	}
	
	/** Indica se o dominó está tombado.
	 * <br>Pode não estar completamente tombado se estiver caido sobre outro dominó)
	 * @return true, se estiver tombado
	 */
	@Override
	public boolean estaTombado() {	
		return angulo >= ANGULO_SUSPENSOE || angulo <= ANGULO_SUSPENSOD;
	}
	
	/** Indica se o dominó está completamente tombado
	 * @return true, se estiver completamente tombado
	 */
	@Override
	public boolean estaCompletamenteTombado() {	
		return angulo == 180 || angulo == 0;
	}
	
	/** define o ângulo de inclinação (0 a 180 graus)
	 * @param angulo o ângulo de inclinação
	 */
	protected void setAngulo( int angulo ) {
		this.angulo = angulo;
	}
	
	/** retorna o ângulo de inclinação (entre 0 e 180)
	 * @return o ângulo de inclinação 
	 */
	@Override
	public int getAngulo() {
		return angulo;
	}

	@Override
	public ComponenteMultiVisual getImagem() {
		return imagem;
	}

	@Override
	public void setImagem(ComponenteMultiVisual img) {
		this.imagem = img;
	}

	@Override
	public Point getPosicaoImagem() {
		return imagem.getPosicao();
	}

	@Override
	public void setPosicaoImagem(Point p) {
		imagem.setPosicaoCentro(p);
	}
}
