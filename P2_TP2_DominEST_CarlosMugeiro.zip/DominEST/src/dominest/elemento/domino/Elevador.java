package dominest.elemento.domino;

import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;

import dominest.elemento.ConstantesJogo;
import dominest.elemento.Plataforma;
import prof.jogos2D.image.ComponenteAnimado;
import prof.jogos2D.image.ComponenteMultiVisual;

public class Elevador extends Domino {

	// Variáveis para o dominó Elevador
	// definição de uma nova ação
	private static final int SUBIR = 20;
	// definição dos ângulos de embate por bater por cima 
	private static final int ANGULO_EMBATE_CIMO_DIR = 60; 
	private static final int ANGULO_EMBATE_CIMO_ESQ = 140;
	private boolean subiu;    // indica se já subiu

	public Elevador(ComponenteMultiVisual c) {
		super(c);
		// TODO Auto-generated constructor stub
	}

	/** desenha o dominó no ambiente gráfico
	 * @param g onde desenhar
	 */
	@Override
	public void desenhar(Graphics2D g) {
		super.desenhar(g);

		AffineTransform t = g.getTransform();
		if( subiu ) {
			// usar transformações para inverter a imagem de queda e parecer que sobe
			g.translate( getImagem().getPosicaoCentro().x, getImagem().getPosicaoCentro().y );
			g.scale( 1, -1);
			g.translate( -getImagem().getPosicaoCentro().x, -getImagem().getPosicaoCentro().y );
		}
		super.desenhar(g);
		g.setTransform( t );

	}



	/** atualiza a posição e o ângulo do dominó
	 */
	@Override
	public void atualiza( ){

		super.atualiza();

		if( getAcao() == SUBIR ) {
			deslocar( 0, -ConstantesJogo.VELOC_QUEDA_DOMINO );
			if( getPlataforma() != null && getPosicao().y <= getPlataforma().getPosicao().y + ConstantesJogo.OFFSET_DOMINO_PLATAFORMA_Y ) {
				// armazenar a direção do tombo
				int tombar = getUltimaAcao();
				setAcao( PARADO );
				//getPlataforma().setDomino( this );
				// este dominó não pode dizer à plataforma que está lá, uma vez que
				// está por baixo e a plataforma pode ter outro por cima
				Point posPlat = getPlataforma().getPosicao();				
				setPosicao( new Point2D.Double( posPlat.x+ConstantesJogo.OFFSET_DOMINO_PLATAFORMA_X,
						posPlat.y-ConstantesJogo.OFFSET_DOMINO_PLATAFORMA_Y + 
						ConstantesJogo.OFFSET_DOMINO_FUNDOPLATAFORMA) );
				subiu = true;
				if( tombar == TOMBAR_DIR )
					empurrarDir();
				else
					empurrarEsq();
			}
			else if( getPlataforma() == null && getPosicao().y < 0 ) {
				getNivel().removeDomino( this );
			}
		}
		else if( subiu && (getAcao() == TOMBAR_DIR || getAcao() == TOMBAR_ESQ) ) {
			atualizaAngulo();
			if( estaAnguloEmbateSuperior() ) {
				Point p;
				if( getAcao() == TOMBAR_DIR )
					p = new Point( getPlataforma().getPosicao().x + 2*getPlataforma().getComprimento(), 
							getPlataforma().getPosicao().y);
				else
					p = new Point( getPlataforma().getPosicao().x - getPlataforma().getComprimento(), 
							getPlataforma().getPosicao().y);

				Plataforma plat = getNivel().getPlataformaAbaixo( p );
				if( Math.abs(plat.getPosicao().y - getPlataforma().getPosicao().y) > ConstantesJogo.ALTURA_MAX_ELEVADORBATER )
					return;
				if( plat.temDomino() ) {
					Domino d = plat.getDomino();
					if(getAcao() == TOMBAR_DIR )
						d.bateLadoEsq( this );
					else
						d.bateLadoDir( this );
				}
			}
			else if( estaAnguloEmbate() ) {
				// ver se tem plataforma onde cair ou se volta a subir
				if( !temPlataformaTombar() ) {
					Point ps = getPosicaoSaidaPlataforma();
					setPosicao( new Point2D.Double(ps.x, (int)getPosicao().y) );
					getPlataforma().setDomino( null );
					setAngulo( 90 );
					getImagem().setVisualAtual( "tombar" );			
					setPlataforma( getNivel().getPlataformaAcima( ps ) );
					setAcao( SUBIR );
				}
			}
		} else { 
			 super.atualiza();  
		}
	}


	/** método usado exclusivamente pelo elevador para ver se bateu pela parte de cima
	 * @return true, se bateu
	 */
	protected boolean estaAnguloEmbateSuperior() {		
		return (getAcao()==TOMBAR_DIR && getAngulo() == ANGULO_EMBATE_CIMO_DIR) || 
			   (getAcao() == TOMBAR_ESQ && getAngulo() == ANGULO_EMBATE_CIMO_ESQ );
	}
	
	/** processa um empurrão para a esquerda
	 */
	@Override
	public void empurrarEsq() {
		if( !estaPe() )
			return;
		//super.empurrarEsq();
		
		if( !subiu ) {
			// só para registar a direção do tombo
			setAcao( TOMBAR_ESQ ); 
			getPlataforma().setDomino( null );
			setAngulo( 90 );
			getImagem().setVisualAtual( "tombar" );			
			setPlataforma( getNivel().getPlataformaAcima( new Point((int)getPosicao().x, (int)getPosicao().y) ) );
			setAcao( SUBIR );
		}
		else {
			super.empurrarEsq();
		}
 
	}
	
	/** processa um empurrão para a direita
	 */
	@Override
	public void empurrarDir() {
		if( !estaPe() )
			return;
		//super.empurrarDir();
		
		if( !subiu ) {
			// só para registar a direçao do tombar
			setAcao( TOMBAR_DIR );
			//setPosicao( new Point2D.Double(p.x, p.y-40) );
			getPlataforma().setDomino( null );
			setAngulo( 90 );
			getImagem().setVisualAtual( "tombar" );			
			setPlataforma( getNivel().getPlataformaAcima( new Point((int)getPosicao().x, (int)getPosicao().y) ) );
			setAcao( SUBIR );
		}
		else {
			super.empurrarDir();
		}
	}
 
}
