package dominest.elemento.domino;

import prof.jogos2D.image.ComponenteMultiVisual;

public class Final extends Domino {

	public Final(ComponenteMultiVisual c) {
		super(c);
		// TODO Auto-generated constructor stub
	}

	/** atualiza a posição e o ângulo do dominó
	 */
	@Override
	public void atualiza( ){

		super.atualiza();

		if( estaCompletamenteTombado() ) {			
			for( Domino d : getNivel().getDominos() )
				if( !d.estaTerminado() ) {
					getNivel().perdeNivel("Nem todos os dominós estão tombados" );
					return;
				}
			if( !getNivel().getPorta().estaAberta() )
				getNivel().getPorta().abrir();
		} 
	}

	/** indica se o dominó pode ser pegado
	 * @return true se o dominó pode ser pegado
	 */
	@Override
	public boolean podeSerPegado() { 
		// um final nunca pode ser pegado
		return false; 
	}

}
