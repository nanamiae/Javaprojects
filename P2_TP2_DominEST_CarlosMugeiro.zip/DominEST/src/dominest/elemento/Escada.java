package dominest.elemento;

import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;

import prof.jogos2D.image.ComponenteVisual;

/** Representa uma escada no jogo
 * @author F. Sergio Barbosa
 *
 */
public class Escada {
	
	private Rectangle area;           // área ocupada pela escada
	private ComponenteVisual imagem;  // imagem da escada
	
	/** Constroi uma escada
	 * @param inicio coordenada do inicio 
	 * @param fim coordenada do fundo (a escada deve ter alguma largura, senão a formiga não a deteta)
	 * @param imgOffset offset entre a imagem da escada e a posição dela
	 * @param img a imagem da escada
	 */
	public Escada( Point inicio, Point fim, int imgOffset, ComponenteVisual img ) {
		area = new Rectangle(inicio.x, inicio.y,fim.x - inicio.x+1, fim.y-inicio.y+1);
		imagem = img;
	}

	/** desenha a escada 
	 * @param g ambiente gráfico onde desenhar a escada
	 */
	public void desenhar(Graphics2D g) {
		imagem.desenhar( g );
		
	}

	/** Indica se uma coordenada está dentro da área da escada
	 * @param p coordenada a verificar
	 * @return true, se a coordenada estiver dentro da área da escada
	 */
	public boolean estaDentro( Point p ) {
		return area.contains( p );	
	}
}
