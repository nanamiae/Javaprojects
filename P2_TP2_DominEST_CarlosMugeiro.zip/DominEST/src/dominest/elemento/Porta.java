package dominest.elemento;

import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;

import prof.jogos2D.image.ComponenteAnimado;
import prof.jogos2D.image.ComponenteVisual;

/** Representa a porta de saída do nível.
 * A porta só é aberta quando o dominó final for tombado e, para ganhar,
 * o jogador deve atingir a porta de saída antes do tempo terminar
 * 
 * @author F. Sergio Barbosa
 */
public class Porta {

	private Rectangle area;
	private ComponenteAnimado imagem;
	private boolean aberta;  // indica se a porta está aberta
	
	/** Cria uma porta de saída
	 * @param p posição da porta
	 * @param comp comprimento
	 * @param alt altura
	 * @param imgAberta imagem da porta
	 */
	public Porta( Point p, int comp, int alt, ComponenteAnimado imgAberta ) {
		area = new Rectangle( p.x, p.y, comp, alt );
		imagem = imgAberta;
		imagem.setPosicao( p );
		// a animação de abertura deve estar pausada e nunca se repete
		imagem.setCiclico( false );
		imagem.setPausa( true );
	}

	/** abre a porta
	 */
	public void abrir() {
		aberta = true;
		imagem.setPausa( false ); // faz a animação de abrir
	}
	
	/** indica se a porta está aberta
	 * @return true, se estiver aberta
	 */
	public boolean estaAberta() {
		return aberta;
	}
	
	/** desenha a porta
	 * @param g onde desenhar
	 */
	public void desenhar( Graphics2D g) {
		imagem.desenhar( g );
		if( !aberta )
			imagem.setFrameNum(0);
	}
	
	/** indica se uma dada coordenada está dentro da área da porta
	 * @param p coordenada a testar
	 * @return true se estiver dentro da área
	 */
	public boolean estaDentro( Point p ) {
		return area.contains( p );
	}

	/** retorna a área ocupada pela porta
	 * @return a área ocupada pela porta
	 */
	public Rectangle getArea() {
		return area;
	}

	/** define a posição da porta
	 * @param p  a posição da porta
	 */
	public void setPosicao(Point p) {
		area.x = p.x;
		area.y = p.y;
		imagem.setPosicao( p );
	}
	
	/** retorna a posição da porta
	 * @return a posição da porta
	 */
	public Point getPosicao() {
		return new Point( area.x, area.y );
	}

	/** devolve a imagem da porta
	 * @return a imagem da porta
	 */
	public ComponenteVisual getImagem() {
		return imagem;
	}

	/** Indica se a porta está completamente aberta. <br>
	 * Para estar completamente aberta tem de estar aberta
	 * e a animação de abertura ter terminado
	 * @return true, se está completamente aberta 
	 */
	public boolean estaCompletamenteAberta() {
		return estaAberta() && imagem.numCiclosFeitos() >= 1;
	}
}
